import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-5SSFCO5C.js";
import "./chunk-4Z7FXD6Z.js";
import "./chunk-SVMM2JLA.js";
import "./chunk-A22KLDL4.js";
import "./chunk-LCBAU2VD.js";
import "./chunk-62672OIL.js";
import "./chunk-YHCV7DAQ.js";
export {
  MatDivider,
  MatDividerModule
};
