import {
  MatDivider,
  MatDividerModule
} from "./chunk-UQUR35XD.js";
import "./chunk-DNQIYZQH.js";
import "./chunk-ISONF2Q2.js";
import "./chunk-GTLAZMWD.js";
import "./chunk-ERQUMRY4.js";
import "./chunk-V6IJKV5F.js";
export {
  MatDivider,
  MatDividerModule
};
