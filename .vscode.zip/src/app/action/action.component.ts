import { Component,OnInit} from '@angular/core';
import {MatCardModule} from '@angular/material/card';
import {MatButtonModule} from '@angular/material/button';
import movieData from '../../assets/movies.json';


@Component({
  selector: 'app-action',
  imports: [MatCardModule,MatButtonModule],
  templateUrl: './action.component.html',
  styleUrl: './action.component.css'
})
export class ActionComponent {
  movies = [
    { title: 'Movie 1' },
    { title: 'Movie 2' }
  ];
}